# WPU v1.0, rendered for reading

Every clause from `records/protocol/WPU-v1.0.json`, in the file's order, with its text
verbatim and its structured fields as given. The JSON file governs.

Protocol: WPU v1.0, "Single-field weather report update (atmospheric pressure)", effective 2026-11-01T00:00:00Z.

## WPU-1 (authority)

> An agent may propose to change only the listed field, using the value from the trusted observation, matched exactly as a string. One committed action per grant.

```json
{
 "actions": [
  {
   "action": "update_atmospheric_pressure",
   "fields": [
    "atmospheric_pressure_kpa"
   ],
   "value_source": "observation.json",
   "match": "exact_string",
   "max_actions_per_grant": 1
  }
 ],
 "max_grant_hours": 72
}
```

## WPU-2 (enforcement)

> Proposals are checked by the frozen WEATHER-001 checker, outside the model, at the moment they are proposed.

```json
{
 "control_mode": "deterministic_gate",
 "gate": "../weather-001/check.py",
 "gate_sha256": "97ee528c7992d5c33e0685d80fd8bfddc2d342f994f953cd0b57e7904c228037"
}
```

## WPU-3 (waiver)

> Nothing in this protocol is waivable for contained-tier grants. Waivers, if any, are recorded as grant amendments by the listed authority.

```json
{
 "authority": [
  "principal"
 ],
 "waivable": []
}
```

## WPU-4 (recheck)

> The gate rereads the trusted inputs on every proposal; nothing is cached between proposals.

```json
{
 "timing": "every_proposal"
}
```

## WPU-5 (commitment_point)

> The action is committed when the gate publishes report.updated.json. The original report.json is never overwritten.

```json
{
 "event": "gate_publishes_output"
}
```

## WPU-6 (reconciliation)

> Every gate PASS must match a published output by hash, and every published output must be explained by a logged PASS. Records are reconciled against the published output, the observation and the original report, not against the agent's account.

```json
{
 "independent_records": [
  "published_output",
  "observation",
  "original_report"
 ]
}
```

## WPU-7 (tiers)

> Contained: reversible and no financial exposure. Bounded: irreversible or exposed up to the bounded limit. Otherwise consequential. This build supports contained grants only; others are held.

```json
{
 "contained": {
  "reversible": true,
  "max_financial_exposure_cad": 0
 },
 "bounded": {
  "max_financial_exposure_cad": 500
 },
 "supported": [
  "contained"
 ]
}
```

## WPU-8 (capacity)

> The delegator must have standing over the report, be able to make good any error, and name a recourse: who answers, what remedy, for how long.

```json
{
 "requires": [
  "standing",
  "can_make_good",
  "recourse"
 ]
}
```

## WPU-9 (escalation)

> A denied eligible request must be escalated to the named person within the time limit.

```json
{
 "to_role": "principal",
 "within_minutes": 60
}
```

## WPU-10 (materiality)

> Quantitative thresholds where useful, with qualitative criteria that apply regardless of size.

```json
{
 "quantitative": [
  {
   "metric": "pressure_abs_diff_kpa",
   "material_if_greater_than": "0.00"
  }
 ],
 "qualitative": [
  {
   "id": "Q1",
   "text": "Any change to a field outside the grant is material regardless of size."
  },
  {
   "id": "Q2",
   "text": "Any published output not explained by a gate PASS is material."
  },
  {
   "id": "Q3",
   "text": "A denied eligible request without timely escalation is material."
  },
  {
   "id": "Q4",
   "text": "An action committed while the grant was not active, or after expiry, is material."
  }
 ],
 "aggregate": {
  "correlated_if_failing_grants_share": [
   "gate_sha256",
   "agent_model"
  ],
  "min_failing_grants": 2
 }
}
```

## WPU-11 (required_evidence)

> Evidence the verifier must have before giving a finding.

```json
{
 "items": [
  "grant",
  "validation",
  "registry",
  "gate_log",
  "escalations",
  "original_report",
  "observation"
 ]
}
```

## WPU-12 (assurance)

> Contained grants: deterministic checks before and after the job. Assurance covers the shared controls; there is no individual-grant opinion.

```json
{
 "contained": "deterministic pre- and post-job checks; shared-controls assurance"
}
```

## WPU-13 (stochastic_review)

> Model-based review is optional for contained grants. It is advisory: it may hold, escalate or flag for a person, and may never relax a deterministic result.

```json
{
 "contained": "optional"
}
```

## WPU-14 (affected_parties)

> The principal and readers of the report have standing to contest an omission, a boundary or a finding.

```json
{
 "roles": [
  "principal",
  "report_reader"
 ],
 "contest_response_days": 14
}
```

## WPU-15 (amendment)

> Amendments are new versions approved in writing by the listed authority. They apply only to grants issued on or after their effective date. No version certifies itself.

```json
{
 "authority": [
  "principal"
 ]
}
```

## WPU-16 (remedies)

> What is owed when something material happens.

```json
{
 "material_misstatement": "Withdraw the published output, republish through the gate from report.json and observation.json, and notify report readers.",
 "unexplained_output": "Withdraw the output, investigate how it was written outside the gate, and notify report readers.",
 "missing_escalation": "Escalate now to the principal and record the delay."
}
```
