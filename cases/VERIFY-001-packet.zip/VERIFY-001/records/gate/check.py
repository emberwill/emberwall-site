"""Validate one untrusted pressure proposal against trusted local JSON files."""

import argparse
from datetime import datetime
from decimal import Decimal
import json
import os
from pathlib import Path
import re
import tempfile


FIELD = "atmospheric_pressure_kpa"
OPERATION = "update_atmospheric_pressure"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def exact_keys(value, keys, label):
    require(type(value) is dict and set(value) == set(keys),
            f"{label}: missing or unexpected keys")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key}")
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError(f"invalid JSON constant: {value}")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"),
                      object_pairs_hook=unique_object,
                      parse_constant=invalid_constant)


def pressure(value):
    require(type(value) is str and
            re.fullmatch(r"(?:0|[1-9][0-9]*)\.[0-9]{2}", value) is not None,
            "pressure must be a canonical decimal string with two decimal places")
    require(Decimal(value) > 0, "pressure must be positive")
    return value


def timestamp(value):
    require(type(value) is str and re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z", value),
        "timestamp must be YYYY-MM-DDTHH:MM:SSZ")
    return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ")


def validate(contract, report, observation, proposal):
    exact_keys(contract, {"station_id", "operation", "field", "unit",
                          "decimal_places"}, "contract")
    station = contract["station_id"]
    require(type(station) is str and re.fullmatch(r"[A-Z0-9_\-]{1,64}", station),
            "invalid contract station identifier")
    require(contract["operation"] == OPERATION and contract["field"] == FIELD
            and contract["unit"] == "kPa"
            and type(contract["decimal_places"]) is int
            and contract["decimal_places"] == 2, "unsupported contract constraints")

    require(type(report) is dict and type(observation) is dict,
            "report and observation must be objects")
    require(report.get("station_id") == station
            and observation.get("station_id") == station, "station mismatch")
    require(timestamp(observation.get("observed_at")) >
            timestamp(report.get("observed_at")), "observation is stale or equal")
    trusted_pressure = pressure(observation.get(FIELD))
    pressure(report.get(FIELD))

    exact_keys(proposal, {"operation", "source", "changes"}, "proposal")
    require(proposal["operation"] == OPERATION, "unauthorized operation")
    exact_keys(proposal["source"], {"station_id", "observed_at"}, "source")
    require(proposal["source"]["station_id"] == station, "source station mismatch")
    require(proposal["source"]["observed_at"] == observation["observed_at"],
            "source timestamp mismatch")
    exact_keys(proposal["changes"], {FIELD}, "changes")
    require(pressure(proposal["changes"][FIELD]) == trusted_pressure,
            "proposed pressure does not match trusted observation")
    updated = report.copy()
    updated[FIELD] = trusted_pressure
    return updated


def atomic_write(path, report):
    # Serialize before creating a file; reject non-finite numbers anywhere.
    payload = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="\n",
                                         dir=path.parent, prefix=".report.updated-",
                                         suffix=".tmp", delete=False) as output:
            temporary = Path(output.name)
            output.write(payload)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("proposal", type=Path, help="path to an untrusted JSON proposal")
    args = parser.parse_args()
    try:
        # These paths are fixed, relative to the working directory, never supplied
        # by the proposal. Read trusted inputs independently on every invocation.
        updated = validate(read_json(Path("contract.json")),
                           read_json(Path("report.json")),
                           read_json(Path("observation.json")),
                           read_json(args.proposal))
        atomic_write(Path("report.updated.json"), updated)
    except (OSError, ValueError, TypeError, RecursionError) as error:
        print(f"DENY: {error}")
        return 1
    print("PASS: wrote report.updated.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
