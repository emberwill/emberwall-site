"""Optional check of the VERIFY-001 packet. Python 3, standard library only.

Run from the packet folder:  python verify_packet.py

1. Every file listed in MANIFEST.sha256 is present and matches its SHA-256.
2. Each log (registry, gate log, escalation log) is an unbroken hash chain:
   each entry's hash is the SHA-256 of its canonical JSON (keys sorted, no spaces)
   without the "hash" field, and its "prev" is the previous entry's hash.
3. The grant and validation files for G2 and G3 match the hashes the registry
   recorded when they were made (file bytes), and the protocol matches the hash the
   grants cite (canonical JSON).
It reports what it finds and draws no conclusion about the grants.
"""
import hashlib, json, pathlib

HERE = pathlib.Path(__file__).resolve().parent
R = HERE / "records"
ok = True


def canon(v):
    return json.dumps(v, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha(b):
    return hashlib.sha256(b).hexdigest()


def report(good, text):
    global ok
    ok = ok and good
    print(("ok      " if good else "PROBLEM ") + text)


for line in (HERE / "MANIFEST.sha256").read_text(encoding="utf-8").splitlines():
    digest, name = line.split("  ", 1)
    p = HERE / name
    report(p.exists() and sha(p.read_bytes()) == digest, f"manifest: {name}")

logs = {}
for name in ("registry.jsonl", "gate_log.jsonl", "escalations.jsonl"):
    entries = [json.loads(x) for x in (R / name).read_text(encoding="utf-8").splitlines() if x.strip()]
    logs[name] = entries
    prev, good = "0" * 64, True
    for i, e in enumerate(entries, 1):
        body = {k: v for k, v in e.items() if k != "hash"}
        good = good and e.get("seq") == i and e.get("prev") == prev and sha(canon(body).encode()) == e.get("hash")
        prev = e.get("hash")
    report(good, f"hash chain: {name} ({len(entries)} entries)")

protocol = json.loads((R / "protocol/WPU-v1.0.json").read_text(encoding="utf-8"))
for g in ("G2", "G3"):
    reg = [e for e in logs["registry.jsonl"] if e["grant_id"] == g]
    issued = [e for e in reg if e["event"] == "issued"][0]
    validated = [e for e in reg if e["event"] == "validated"][0]
    report(sha((R / f"grants/{g}.json").read_bytes()) == issued["grant_sha256"],
           f"{g}: grant file matches the registry's issue record")
    report(sha((R / f"validation/{g}.json").read_bytes()) == validated["validation_sha256"],
           f"{g}: validation file matches the registry's validation record")
    grant = json.loads((R / f"grants/{g}.json").read_text(encoding="utf-8"))
    report(sha(canon(protocol).encode()) == grant["protocol"]["sha256"],
           f"{g}: protocol file matches the hash the grant cites")

print("\nAll checks passed." if ok else "\nSome checks failed; see PROBLEM lines.")
