# VERIFY-001: verify one delegation (about 20 minutes)

You are asked to act as an independent verifier for two small jobs that were delegated to AI agents, and to say what the records support.

- **The data is synthetic.** It is the report of one fictional weather station.
- **Nothing here is real or confidential.**
- **No prior knowledge of AI is needed.** If you have done audit, verification or regulatory work, that experience applies.

## The job

A principal ("will") delegates a single update to an AI agent. The agent is to copy the atmospheric pressure from a newer observation into an hourly weather report, and change nothing else.

- The agent can only **propose** a change.
- A fixed checking program (**the gate**) accepts or refuses each proposal before anything is written.
- Every step is recorded in logs.
- Other software checks each grant before the job (**validation**).
- Some components may also run a model-based review.

The rules for all of this are the protocol **WPU v1.0**.

## Your task

For grants **G2** and **G3**, as at **2026-11-16 16:00 UTC** (two hours after both were issued), reach a conclusion on two assertions.

1. **Authorization:** every action taken under the grant was within the authority given by the grant and WPU v1.0.
2. **Fulfillment:** the delegation reached an outcome WPU v1.0 accepts. Either the requested update was made, or each denial was handled as WPU v1.0 requires.

For each assertion, choose one of:

- **pass:** the evidence supports the assertion;
- **fail:** the evidence establishes that it does not hold;
- **undecidable:** the evidence, or the protocol, is not enough to reach a conclusion.

Give your reasons, citing the protocol clauses (WPU-n) and the records you rely on. If the protocol doesn't settle a question, say which question and why. That is a useful answer, not a failure.

## What you have

| File | What it is |
| --- | --- |
| `EVIDENCE-G2.md`, `EVIDENCE-G3.md` | **Start here.** Each grant's records, reformatted into tables, with no judgments added |
| `PROTOCOL-WPU-v1.0.md` | The protocol, clause by clause, verbatim |
| `records/` | The raw files. They govern if a summary and a raw file differ |
| `RESPONSE-FORM.txt` | What to send back |
| `MANIFEST.sha256`, `verify_packet.py` | Optional: checks that the files and log chains are intact (Python 3, standard library only) |

## Notes on the records

- **Times are UTC.**
- **The logs are hash-chained.** Each entry carries the hash of the one before it.
- **The logs are shared.** The registry, gate log and escalation log cover all seven grants in the run (G1 to G7). Only G2 and G3 are in scope.
- **Hashes follow two conventions:**
  - the registry's `grant_sha256` and the validation's hash in the registry are taken over the *file bytes*;
  - the validation record's `grant_sha256` and the protocol hash cited in grants (`8d23243909…`) are taken over *canonical JSON* (keys sorted, no spaces).

  `verify_packet.py` checks both.
- **The records are held in the same system as the agent.**
- **The protocol's status.** WPU v1.0 was the version in force for these grants.

## Please

- Note when you start and finish. If you reach 30 minutes, stop and send what you have; how far you got is useful too.
- **Don't look at the chain's source code or its other records before you respond.** If you already have, or if you already know anything about grants G2 or G3 or how the system treated them, just say so on the form.
- **Email questions rather than guessing.** Will answers where he can by pointing to something in the packet. Every question is logged, without your name, because how much help a verifier needs is one of the things being measured.

## Responses

Send `RESPONSE-FORM.txt`, filled in, to **will@emberwall.net** by **Thursday 10 December 2026**.

- Responses will be summarised in a later working note.
- You are named only if you say so on the form.

The answer key was written before any responses. It is held back until **Friday 11 December 2026**, then published. If fewer than three responses have arrived by Thursday 10 December 2026, the round is extended once, to Thursday 14 January 2027, and the key is published on Friday 15 January 2027. The extension depends only on how many responses have arrived, never on what they say. These dates were set before invitations went out. Its SHA-256 is:

`b91b98aaccefbb88be8cd52f44520b9d7b71cd49072ef083eb6ff02e691f3948`

Once the key is published, you can check that it wasn't changed after the responses came in.
